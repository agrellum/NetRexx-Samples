The article "2006_orx17_ooRexxUnit-article.pdf" was created for the proceedings
of the 17th International Rexx Symposium (cf. <http://www.RexxLA.org>) which
took place in Austin, Texas, in 2006. This version is as of 2006-12-30,
reflecting all changes to the ooRexxUnit framework that were applied by then.

"2006_orx17_ooRexxUnit_code.zip" contains the article's examples and also a zip
archive of the ooRexxUnit framework as of 2006-12-30.

As the framework is subject to changes/improvements you should make sure to use
the latest version from:

   <http://oorexx.svn.sourceforge.net/viewvc/oorexx/test/framework/>,

namely the files "OOREXXUNIT.CLS" and "runTestUnit.rex".

---rgf, 2006-12-31

P.S.: This readme's home is intended to be at:

        <http://oorexx.svn.sourceforge.net/viewvc/oorexx/test/framework/docs/>

