counter=0
while true; do
	rexx testOORexx.rex -X native_api
    counter=$((counter+1))
    echo "Counter for rexx testOORexx.rex -X native_api : $counter time(s); Sleeping for 10"
	echo "Press [CTRL+C] to stop.."
	sleep 10
done
